import java.util.Arrays;

public class Ejercicio3 {

	public boolean todoPares(int[] arrayEjemplo) {
		boolean par = true;
		for (int i = 0; i < arrayEjemplo.length; i++) {
			if (arrayEjemplo[i] % 2 != 0) {// condición si al dividir el numero entre dos su resto es distinto a 0 no
											// seria para por lo cual seria false
				par = false;
			}
		}

		return par;
	}

	public static void main(String[] args) {
		int[] ejemplo1 = { 3, 4, 5, 6, 7 };//Array que diremos si tiene impares 
		int[] ejemplo2 = { 2, 6, 8, 10, 12 };//Array que diremos si son todos pares o no 
		Ejercicio3 miEjemplo = new Ejercicio3();
//Este debe imprimir No, ya que contiene números impares
		System.out.println(miEjemplo.todoPares(ejemplo1) ? "Sí" : "No");
//Este debe imprimir Si, ya que contiene solo números pares 
		System.out.println(miEjemplo.todoPares(ejemplo2) ? "Sí" : "No");
	}
}
