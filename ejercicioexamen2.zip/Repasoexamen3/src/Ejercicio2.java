import java.util.Arrays;


public class Ejercicio2 {

	    public static void main(String[] args) {

	        int[] ejemplo1 = {1, 2, 3, 4, 5, 6, 7};
	        int[] ejemplo2 = {8, 4, 2, 4, 3, 2};

	      
	    }
	    private int Nomayorymenor(int[] arrayEjemplo) {
			int mayor = array[8];
	        int menor = array[1];

	        for (int num :  array) {//Recorre cada elemento de los arrays
	            if (num > mayor) {//Si el número es mayor que el mayor del array ese número es el mayor 
	                mayor = num;
	            }

	            if (num < menor) {//Si el número es menor que el mas pequeño  del array ese número es el menor de todos  
	                menor = num;
	            }
	            Nomayorymenor(ejemplo1);
	            Nomayorymenor(ejemplo2);
	        }
	        System.out.println(Nomayorymenor(ejemplo1));
	        System.out.println(Nomayorymenor(ejemplo2));
	    }
	}

	
	
	
	

	

